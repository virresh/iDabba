class Bookmark < ApplicationRecord
end
